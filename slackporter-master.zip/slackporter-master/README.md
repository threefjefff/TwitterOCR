# Slack Emoji Porter

This is a node server for moving slack emoji between Slack teams. I have this problem and I thought perhaps other people did too.

Log in with a source and destination Slack account to get a list of non-colliding emoji, then click on an emoji to transfer it between teams.

If you use this tool, you may receive emails from Slack that new API tokens have been issued for your account. This is normal.
